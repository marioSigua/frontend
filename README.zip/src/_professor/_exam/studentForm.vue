<template>
  <div>
    <button>Import Question</button>

    <div></div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="css" scoped></style>
